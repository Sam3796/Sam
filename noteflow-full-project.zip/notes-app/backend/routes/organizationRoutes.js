import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { listFolders, createFolder, updateFolder, deleteFolder, listTags, createTag, deleteTag } from '../controllers/organizationController.js';
const router = Router(); router.use(protect);
router.get('/folders',listFolders); router.post('/folders',createFolder); router.patch('/folders/:id',updateFolder); router.delete('/folders/:id',deleteFolder);
router.get('/tags',listTags); router.post('/tags',createTag); router.delete('/tags/:id',deleteTag);
export default router;
