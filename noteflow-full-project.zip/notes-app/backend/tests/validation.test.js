import test from 'node:test';
import assert from 'node:assert/strict';

test('health endpoint path is documented', () => {
  assert.equal('/api/health', '/api/health');
});
test('password policy requires at least eight characters', () => {
  const valid = password => typeof password === 'string' && password.length >= 8 && password.length <= 128;
  assert.equal(valid('password123'), true);
  assert.equal(valid('short'), false);
});
