import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { connectDB } from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import noteRoutes from './routes/noteRoutes.js';
import organizationRoutes from './routes/organizationRoutes.js';
import { notFound, errorHandler } from './middleware/errors.js';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
const allowed = (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map(x=>x.trim());
app.use(cors({ origin(origin, callback) { if (!origin || allowed.includes(origin)) return callback(null,true); callback(new Error('Origin not allowed by CORS')); }, credentials: false }));
app.use(express.json({ limit:'1mb' }));
app.use(express.urlencoded({ extended:false, limit:'1mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('tiny'));
app.use('/api/auth', rateLimit({ windowMs:15*60*1000, limit:30, standardHeaders:'draft-7', legacyHeaders:false }), authRoutes);
app.use('/api/notes', rateLimit({ windowMs:15*60*1000, limit:300, standardHeaders:'draft-7', legacyHeaders:false }), noteRoutes);
app.use('/api', organizationRoutes);
app.get('/api/health', (req,res)=>res.json({status:'ok',service:'noteflow-api',timestamp:new Date().toISOString()}));
app.use(notFound);
app.use(errorHandler);

const port = process.env.PORT || 5000;
if (process.env.NODE_ENV !== 'test') {
  connectDB().then(()=>app.listen(port,()=>console.log(`API listening on ${port}`))).catch(err=>{console.error('Database startup failed',err);process.exit(1);});
}
export default app;
