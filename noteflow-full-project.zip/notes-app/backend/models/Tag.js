import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  name: { type: String, required: true, trim: true, lowercase: true, maxlength: 30 },
  color: { type: String, default: '#7c6cf2' }
}, { timestamps: true });
schema.index({ userId: 1, name: 1 }, { unique: true });
export default mongoose.model('Tag', schema);
