import mongoose from 'mongoose';
const noteSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, trim: true, maxlength: 200, default: 'Untitled' },
  content: { type: String, default: '' },
  folderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Folder', default: null },
  tags: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Tag' }],
  color: { type: String, enum: ['default','yellow','green','blue','pink','purple','orange'], default: 'default' },
  isPinned: { type: Boolean, default: false },
  isArchived: { type: Boolean, default: false },
  isDeleted: { type: Boolean, default: false },
  deletedAt: { type: Date, default: null }
}, { timestamps: true });
noteSchema.index({ userId: 1, updatedAt: -1 });
noteSchema.index({ userId: 1, isDeleted: 1, isArchived: 1, isPinned: -1 });
noteSchema.index({ title: 'text', content: 'text' });
export default mongoose.model('Note', noteSchema);
