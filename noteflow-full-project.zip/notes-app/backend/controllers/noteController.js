import { z } from 'zod';
import Note from '../models/Note.js';
import Folder from '../models/Folder.js';
import Tag from '../models/Tag.js';
import { asyncHandler } from '../utils/asyncHandler.js';

const colors = ['default','yellow','green','blue','pink','purple','orange'];
const noteInput = z.object({
  title: z.string().max(200).optional(),
  content: z.string().max(200000).optional(),
  folderId: z.string().nullable().optional(),
  tags: z.array(z.string()).max(30).optional(),
  color: z.enum(colors).optional(),
  isPinned: z.boolean().optional(),
  isArchived: z.boolean().optional(),
  isDeleted: z.boolean().optional()
}).strict();

async function validateRefs(userId, data) {
  if (data.folderId && !(await Folder.exists({ _id: data.folderId, userId }))) throw Object.assign(new Error('Folder not found'), { status: 400 });
  if (data.tags?.length) {
    const count = await Tag.countDocuments({ _id: { $in: data.tags }, userId });
    if (count !== new Set(data.tags).size) throw Object.assign(new Error('One or more tags are invalid'), { status: 400 });
  }
}
export const listNotes = asyncHandler(async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 30));
  const filter = { userId: req.user._id };
  const view = req.query.view || 'active';
  if (view === 'trash') filter.isDeleted = true;
  else {
    filter.isDeleted = false;
    if (view === 'archived') filter.isArchived = true;
    else if (view === 'pinned') { filter.isArchived = false; filter.isPinned = true; }
    else filter.isArchived = false;
  }
  if (req.query.folderId) filter.folderId = req.query.folderId;
  if (req.query.tagId) filter.tags = req.query.tagId;
  if (req.query.q) filter.$or = [{ title: { $regex: escapeRegex(String(req.query.q).slice(0,100)), $options: 'i' } }, { content: { $regex: escapeRegex(String(req.query.q).slice(0,100)), $options: 'i' } }];
  const sort = req.query.sort === 'created' ? { createdAt: -1 } : req.query.sort === 'title' ? { title: 1 } : { isPinned: -1, updatedAt: -1 };
  const [notes, total] = await Promise.all([
    Note.find(filter).populate('tags', 'name color').sort(sort).skip((page - 1) * limit).limit(limit),
    Note.countDocuments(filter)
  ]);
  res.json({ notes, page, pages: Math.ceil(total / limit), total });
});
function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
export const createNote = asyncHandler(async (req, res) => {
  const data = noteInput.parse(req.body); await validateRefs(req.user._id, data);
  const note = await Note.create({ ...data, userId: req.user._id });
  res.status(201).json({ note });
});
export const getNote = asyncHandler(async (req, res) => {
  const note = await Note.findOne({ _id: req.params.id, userId: req.user._id }).populate('tags', 'name color');
  if (!note) return res.status(404).json({ message: 'Note not found' });
  res.json({ note });
});
export const updateNote = asyncHandler(async (req, res) => {
  const data = noteInput.parse(req.body); await validateRefs(req.user._id, data);
  const note = await Note.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, { $set: data }, { new: true, runValidators: true }).populate('tags', 'name color');
  if (!note) return res.status(404).json({ message: 'Note not found' });
  res.json({ note });
});
export const deleteNote = asyncHandler(async (req, res) => {
  const note = await Note.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, { $set: { isDeleted: true, deletedAt: new Date(), isPinned: false } }, { new: true });
  if (!note) return res.status(404).json({ message: 'Note not found' });
  res.json({ message: 'Moved to trash', note });
});
export const restoreNote = asyncHandler(async (req, res) => {
  const note = await Note.findOneAndUpdate({ _id: req.params.id, userId: req.user._id, isDeleted: true }, { $set: { isDeleted: false, isArchived: false, deletedAt: null } }, { new: true });
  if (!note) return res.status(404).json({ message: 'Trashed note not found' });
  res.json({ note });
});
export const permanentDelete = asyncHandler(async (req, res) => {
  const result = await Note.deleteOne({ _id: req.params.id, userId: req.user._id, isDeleted: true });
  if (!result.deletedCount) return res.status(404).json({ message: 'Trashed note not found' });
  res.json({ message: 'Permanently deleted' });
});
export const duplicateNote = asyncHandler(async (req, res) => {
  const source = await Note.findOne({ _id: req.params.id, userId: req.user._id, isDeleted: false });
  if (!source) return res.status(404).json({ message: 'Note not found' });
  const copy = await Note.create({ userId: req.user._id, title: `${source.title} (copy)`, content: source.content, folderId: source.folderId, tags: source.tags, color: source.color });
  res.status(201).json({ note: copy });
});
