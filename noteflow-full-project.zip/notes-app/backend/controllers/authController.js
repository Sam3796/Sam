import bcrypt from 'bcryptjs';
import { z } from 'zod';
import User from '../models/User.js';
import { signToken } from '../utils/token.js';
import { asyncHandler } from '../utils/asyncHandler.js';

const registerSchema = z.object({ name: z.string().trim().min(2).max(80), email: z.string().email().max(254), password: z.string().min(8).max(128) });
const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1).max(128) });
const safeUser = u => ({ id: u._id, name: u.name, email: u.email, avatar: u.avatar });

export const register = asyncHandler(async (req, res) => {
  const data = registerSchema.parse(req.body);
  const email = data.email.toLowerCase();
  if (await User.exists({ email })) return res.status(409).json({ message: 'An account with this email already exists' });
  const user = await User.create({ ...data, email, password: await bcrypt.hash(data.password, 12) });
  res.status(201).json({ user: safeUser(user), token: signToken(user._id) });
});
export const login = asyncHandler(async (req, res) => {
  const data = loginSchema.parse(req.body);
  const user = await User.findOne({ email: data.email.toLowerCase() }).select('+password');
  if (!user || !(await bcrypt.compare(data.password, user.password))) return res.status(401).json({ message: 'Email or password is incorrect' });
  res.json({ user: safeUser(user), token: signToken(user._id) });
});
export const me = asyncHandler(async (req, res) => res.json({ user: safeUser(req.user) }));
export const updateProfile = asyncHandler(async (req, res) => {
  const data = z.object({ name: z.string().trim().min(2).max(80) }).parse(req.body);
  req.user.name = data.name; await req.user.save(); res.json({ user: safeUser(req.user) });
});
export const changePassword = asyncHandler(async (req, res) => {
  const data = z.object({ currentPassword: z.string().min(1), newPassword: z.string().min(8).max(128) }).parse(req.body);
  const user = await User.findById(req.user._id).select('+password');
  if (!(await bcrypt.compare(data.currentPassword, user.password))) return res.status(400).json({ message: 'Current password is incorrect' });
  user.password = await bcrypt.hash(data.newPassword, 12); await user.save();
  res.json({ message: 'Password updated. Please sign in again.' });
});
