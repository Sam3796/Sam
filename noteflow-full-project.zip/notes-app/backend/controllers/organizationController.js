import { z } from 'zod';
import Folder from '../models/Folder.js';
import Tag from '../models/Tag.js';
import Note from '../models/Note.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const listFolders = asyncHandler(async (req,res) => {
  const folders = await Folder.find({ userId:req.user._id }).sort({ name:1 }).lean();
  const counts = await Note.aggregate([{ $match:{ userId:req.user._id, isDeleted:false, isArchived:false } }, { $group:{ _id:'$folderId', count:{ $sum:1 } } }]);
  const map = new Map(counts.map(x => [String(x._id),x.count]));
  res.json({ folders:folders.map(f => ({...f, noteCount:map.get(String(f._id)) || 0})) });
});
export const createFolder = asyncHandler(async (req,res) => {
  const {name,color} = z.object({name:z.string().trim().min(1).max(60),color:z.string().optional()}).parse(req.body);
  const folder = await Folder.create({userId:req.user._id,name,color}); res.status(201).json({folder});
});
export const updateFolder = asyncHandler(async (req,res) => {
  const data = z.object({name:z.string().trim().min(1).max(60).optional(),color:z.string().optional()}).parse(req.body);
  const folder = await Folder.findOneAndUpdate({_id:req.params.id,userId:req.user._id},{$set:data},{new:true,runValidators:true});
  if(!folder) return res.status(404).json({message:'Folder not found'}); res.json({folder});
});
export const deleteFolder = asyncHandler(async (req,res) => {
  const folder = await Folder.findOneAndDelete({_id:req.params.id,userId:req.user._id});
  if(!folder) return res.status(404).json({message:'Folder not found'});
  await Note.updateMany({userId:req.user._id,folderId:folder._id},{$set:{folderId:null}});
  res.json({message:'Folder deleted; notes were kept'});
});
export const listTags = asyncHandler(async(req,res)=>res.json({tags:await Tag.find({userId:req.user._id}).sort({name:1})}));
export const createTag = asyncHandler(async(req,res)=>{
  const {name,color}=z.object({name:z.string().trim().min(1).max(30),color:z.string().optional()}).parse(req.body);
  const tag=await Tag.create({userId:req.user._id,name,color}); res.status(201).json({tag});
});
export const deleteTag = asyncHandler(async(req,res)=>{
  const tag=await Tag.findOneAndDelete({_id:req.params.id,userId:req.user._id});
  if(!tag)return res.status(404).json({message:'Tag not found'});
  await Note.updateMany({userId:req.user._id},{$pull:{tags:tag._id}});
  res.json({message:'Tag deleted'});
});
