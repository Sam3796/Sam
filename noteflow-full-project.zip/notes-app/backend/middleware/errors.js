export function notFound(req, res) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const status = err.status || ((err.name === 'ValidationError' || err.name === 'ZodError') ? 400 : err.name === 'CastError' ? 404 : 500);
  if (err.code === 11000) return res.status(409).json({ message: 'That value is already in use' });
  res.status(status).json({ message: status === 500 && process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message || 'Server error' });
}
