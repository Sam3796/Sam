import { createContext, useContext, useEffect, useState } from 'react';
import api from '../services/api';
const AuthContext = createContext(null);
export function AuthProvider({children}) {
  const [user,setUser] = useState(null), [loading,setLoading] = useState(true);
  useEffect(()=>{ const token=localStorage.getItem('noteflow_token'); if(!token){setLoading(false);return;} api.get('/auth/me').then(r=>setUser(r.data.user)).catch(()=>localStorage.removeItem('noteflow_token')).finally(()=>setLoading(false)); },[]);
  const login = async (email,password) => { const {data}=await api.post('/auth/login',{email,password}); localStorage.setItem('noteflow_token',data.token); setUser(data.user); };
  const register = async (name,email,password) => { const {data}=await api.post('/auth/register',{name,email,password}); localStorage.setItem('noteflow_token',data.token); setUser(data.user); };
  const logout = () => { localStorage.removeItem('noteflow_token'); setUser(null); };
  const refreshUser = async () => { const {data}=await api.get('/auth/me'); setUser(data.user); };
  return <AuthContext.Provider value={{user,loading,login,register,logout,refreshUser}}>{children}</AuthContext.Provider>;
}
export const useAuth=()=>useContext(AuthContext);
