import {Routes,Route,Navigate} from 'react-router-dom';
import {ToastProvider} from './components/Toast';
import ProtectedRoute from './components/ProtectedRoute';
import AppLayout from './layouts/AppLayout';
import Landing from './pages/Landing';
import {Login,Register,ForgotPassword} from './pages/AuthPages';
import {Dashboard,NotesList,NoteEditorPage,FoldersPage,SettingsPage} from './pages/NotesPages';
function NotFound(){return <div className="not-found"><b>404</b><h1>That page wandered off.</h1><a href="/">Return home</a></div>}
export default function App(){return <ToastProvider><Routes><Route path="/" element={<Landing/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/><Route path="/forgot-password" element={<ForgotPassword/>}/><Route element={<ProtectedRoute/>}><Route path="/app" element={<AppLayout/>}><Route index element={<Dashboard/>}/><Route path="notes" element={<NotesList/>}/><Route path="pinned" element={<NotesList view="pinned"/>}/><Route path="archived" element={<NotesList view="archived"/>}/><Route path="trash" element={<NotesList view="trash"/>}/><Route path="new" element={<NoteEditorPage/>}/><Route path="edit/:id" element={<NoteEditorPage edit/>}/><Route path="folders" element={<FoldersPage/>}/><Route path="settings" element={<SettingsPage/>}/><Route path="profile" element={<SettingsPage/>}/></Route></Route><Route path="*" element={<NotFound/>}/></Routes></ToastProvider>}
