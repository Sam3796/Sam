import {useEditor,EditorContent} from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Highlight from '@tiptap/extension-highlight';
import {Bold,Italic,Underline as UnderlineIcon,List, ListOrdered,Heading2,Code,Undo2,Redo2,Highlighter,Link2,Strikethrough} from 'lucide-react';
const tools=[
 ['bold',Bold],['italic',Italic],['underline',UnderlineIcon],['strike',Strikethrough],
 ['heading',Heading2],['bullet',List],['ordered',ListOrdered],['code',Code],['highlight',Highlighter],['undo',Undo2],['redo',Redo2]
];
export default function Editor({value,onChange}) {
 const editor=useEditor({extensions:[StarterKit,Underline,Link.configure({openOnClick:false}),Highlight],content:value||'',onUpdate:({editor})=>onChange(editor.getHTML())});
 if(!editor)return null;
 const run=(key)=>{const c=editor.chain().focus();({bold:()=>c.toggleBold().run(),italic:()=>c.toggleItalic().run(),underline:()=>c.toggleUnderline().run(),strike:()=>c.toggleStrike().run(),heading:()=>c.toggleHeading({level:2}).run(),bullet:()=>c.toggleBulletList().run(),ordered:()=>c.toggleOrderedList().run(),code:()=>c.toggleCodeBlock().run(),highlight:()=>c.toggleHighlight().run(),undo:()=>c.undo().run(),redo:()=>c.redo().run()})[key]();};
 return <div className="editor-shell"><div className="toolbar">{tools.map(([key,Icon])=><button type="button" key={key} title={key} className={editor.isActive(key==='heading'?'heading':key)?'tool active':'tool'} onClick={()=>run(key)}><Icon size={16}/></button>)}<button type="button" className="tool" title="Add link" onClick={()=>{const url=window.prompt('Enter URL');if(url)editor.chain().focus().setLink({href:url}).run()}}><Link2 size={16}/></button></div><EditorContent editor={editor} className="editor-content"/></div>;
}
