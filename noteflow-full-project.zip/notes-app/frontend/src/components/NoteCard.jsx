import {Pin,Archive,Trash2,Copy,FileText,RotateCcw} from 'lucide-react';
const colors={default:'note-default',yellow:'note-yellow',green:'note-green',blue:'note-blue',pink:'note-pink',purple:'note-purple',orange:'note-orange'};
export default function NoteCard({note,onOpen,onPin,onArchive,onDelete,onDuplicate,onRestore}) {
 const plain=(note.content||'').replace(/<[^>]*>/g,' ').replace(/&nbsp;/g,' ').trim();
 return <article className={`note-card ${colors[note.color]||colors.default}`} onClick={()=>onOpen(note)}>
  <div className="note-card-top"><span className="note-date">{new Date(note.updatedAt).toLocaleDateString(undefined,{month:'short',day:'numeric'})}</span><div className="note-actions">{note.isDeleted?<button title="Restore" onClick={e=>{e.stopPropagation();onRestore(note)}}><RotateCcw size={15}/></button>:<><button title="Pin" onClick={e=>{e.stopPropagation();onPin(note)}}><Pin size={15} fill={note.isPinned?'currentColor':'none'}/></button><button title="Archive" onClick={e=>{e.stopPropagation();onArchive(note)}}><Archive size={15}/></button></>}<button title={note.isDeleted?'Delete permanently':'Move to trash'} onClick={e=>{e.stopPropagation();onDelete(note)}}><Trash2 size={15}/></button></div></div>
  <h3>{note.title||'Untitled'}</h3><p>{plain||'No additional text'}</p>
  <div className="note-card-bottom"><span><FileText size={13}/>{Math.max(1,Math.ceil(plain.length/220))} min read</span>{!note.isDeleted&&<button title="Duplicate" onClick={e=>{e.stopPropagation();onDuplicate(note)}}><Copy size={14}/></button>}</div>
 </article>
}
