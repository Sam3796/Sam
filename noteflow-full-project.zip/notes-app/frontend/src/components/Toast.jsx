import {createContext,useContext,useState} from 'react';
const C=createContext(()=>{});
export function ToastProvider({children}) {
 const [items,setItems]=useState([]);
 const toast=(message,type='success')=>{const id=Date.now()+Math.random();setItems(v=>[...v,{id,message,type}]);setTimeout(()=>setItems(v=>v.filter(x=>x.id!==id)),2800)};
 return <C.Provider value={toast}>{children}<div className="toast-stack">{items.map(x=><div key={x.id} className={`toast ${x.type}`}>{x.message}</div>)}</div></C.Provider>
}
export const useToast=()=>useContext(C);
