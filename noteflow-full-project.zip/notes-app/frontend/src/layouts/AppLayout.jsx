import {NavLink,Outlet,useNavigate} from 'react-router-dom';
import {BookOpen,LayoutDashboard,StickyNote,Pin,Archive,Trash2,Folder,Settings,Plus,LogOut,Search,Sun,Moon,PanelLeftClose,PanelLeftOpen} from 'lucide-react';
import {useAuth} from '../context/AuthContext';
import {useTheme} from '../context/ThemeContext';
import {useState} from 'react';
import api from '../services/api';
export default function AppLayout(){
 const {user,logout}=useAuth(),{theme,setTheme}=useTheme(),nav=useNavigate();
 const [collapsed,setCollapsed]=useState(false),[query,setQuery]=useState('');
 const links=[['/app','Overview',LayoutDashboard],['/app/notes','All notes',StickyNote],['/app/pinned','Pinned',Pin],['/app/archived','Archived',Archive],['/app/trash','Trash',Trash2],['/app/folders','Folders',Folder],['/app/settings','Settings',Settings]];
 return <div className={`app-shell ${collapsed?'sidebar-collapsed':''}`}><aside className="sidebar">
  <div className="brand"><div className="brand-mark"><BookOpen size={19}/></div>{!collapsed&&<span>note<span className="brand-accent">flow</span></span>}<button className="collapse-btn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?<PanelLeftOpen size={17}/>:<PanelLeftClose size={17}/>}</button></div>
  <button className="create-button" onClick={()=>nav('/app/new')}><Plus size={17}/>{!collapsed&&'Create a note'}</button>
  <div className="nav-label">{!collapsed&&'WORKSPACE'}</div><nav>{links.map(([to,label,Icon])=><NavLink end={to==='/app'} key={to} to={to} title={label} className={({isActive})=>`nav-link ${isActive?'selected':''}`}><Icon size={18}/>{!collapsed&&label}</NavLink>)}</nav>
  <div className="sidebar-bottom"><button className="nav-link" onClick={()=>setTheme(theme==='dark'?'light':'dark')}><span className="nav-icon">{theme==='dark'?<Sun size={18}/>:<Moon size={18}/>}</span>{!collapsed&&(theme==='dark'?'Light appearance':'Dark appearance')}</button><div className="profile-mini"><div className="avatar">{user?.name?.[0]?.toUpperCase()||'U'}</div>{!collapsed&&<div><b>{user?.name}</b><small>{user?.email}</small></div>}<button title="Sign out" onClick={()=>{logout();nav('/login')}}><LogOut size={16}/></button></div></div>
 </aside><main className="main-area"><header className="topbar"><div className="crumb">Your workspace <span>/</span> <b>Personal</b></div><div className="top-actions"><div className="global-search"><Search size={16}/><input placeholder="Search your notes..." value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&nav(`/app/notes?q=${encodeURIComponent(query)}`)}/><kbd>↵</kbd></div><button className="avatar avatar-top" onClick={()=>nav('/app/profile')}>{user?.name?.[0]?.toUpperCase()}</button></div></header><div className="page-wrap"><Outlet/></div></main></div>
}
