/** @type {import('tailwindcss').Config} */
export default { content:['./index.html','./src/**/*.{js,jsx}'], darkMode:'class', theme:{ extend:{ colors:{ ink:'#172033', brand:'#7164e8', canvas:'#f5f6fa' }, boxShadow:{ soft:'0 12px 35px rgba(27,34,59,.07)' } } }, plugins:[] };
