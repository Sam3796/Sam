# NoteFlow — Full-stack Notes Application

A deployment-oriented notes app built with React, Vite, Tailwind CSS, Express, MongoDB/Mongoose and JWT authentication.

## Features
- Register, log in, log out, profile update and password change
- JWT-protected REST API with bcrypt password hashing
- Create, edit, delete, restore, permanently delete, pin, archive and duplicate notes
- Search, sort, filter by folder, tags and color
- Rich text editing with TipTap (formatting, headings, lists, links, code blocks, highlight, undo/redo)
- Folders, tags, grid/list view, light/dark theme
- Autosave status, responsive layout, toast feedback
- Export note to TXT / print-to-PDF, import TXT/Markdown
- Rate limiting, Helmet, CORS allowlist, validation, ownership checks
- Health endpoint, Docker Compose, Render and Vercel deployment notes

## Requirements
- Node.js 20+
- MongoDB 6+ or MongoDB Atlas

## Local setup

### 1. Configure backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Set `MONGODB_URI` and a long random `JWT_SECRET` in `backend/.env`.

### 2. Configure frontend
```bash
cd ../frontend
cp .env.example .env
npm install
npm run dev
```
Open http://localhost:5173. Vite proxies `/api` to `http://localhost:5000` in development.

## Production deployment

### Backend (Render)
1. Create a Render Web Service from the repository.
2. Root directory: `backend`
3. Build command: `npm install`
4. Start command: `npm start`
5. Set `NODE_ENV=production`, `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL` (your frontend origin), and optionally `JWT_EXPIRES_IN`.
6. Health check path: `/api/health`

### Frontend (Vercel)
1. Import the repository into Vercel.
2. Root directory: `frontend`
3. Build command: `npm run build`
4. Output directory: `dist`
5. Set `VITE_API_URL` to your backend origin plus `/api`, e.g. `https://your-api.onrender.com/api`.
6. The included `vercel.json` rewrites client routes to `index.html`.

### Docker
At the repository root:
```bash
cp backend/.env.example backend/.env
# Set MONGODB_URI and JWT_SECRET
docker compose up --build
```
Frontend: http://localhost:8080; API: http://localhost:5000/api.

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `PATCH /api/auth/profile`
- `PATCH /api/auth/password`
- `GET|POST /api/notes`
- `GET|PATCH|DELETE /api/notes/:id`
- `POST /api/notes/:id/restore`
- `DELETE /api/notes/:id/permanent`
- `POST /api/notes/:id/duplicate`
- `GET|POST /api/folders`
- `PATCH|DELETE /api/folders/:id`
- `GET|POST /api/tags`
- `DELETE /api/tags/:id`
- `GET /api/health`

All private endpoints require `Authorization: Bearer <token>`.

## Security notes
- Use HTTPS in production and a unique 32+ byte JWT secret.
- Set `CLIENT_URL` to the exact deployed frontend origin.
- Configure MongoDB Atlas network access narrowly.
- For higher assurance, add email-backed password reset delivery and refresh-token rotation. This release includes a reset-token API foundation only when SMTP is configured; see environment variables.
- Never commit `.env` files.

## Tests
```bash
cd backend && npm test
```
The API test suite uses Node's test runner and mocks no database by default; set `TEST_MONGODB_URI` to run database-backed integration tests.


## Scope and production integration notes
- Secure email-based password reset and shareable public links are intentionally not exposed without a configured email/delivery and link-expiration policy. The Forgot Password page explains this rather than pretending an email was sent.
- Folder creation and folder filtering are implemented. The Tag model and API are present; tag assignment UI is a follow-on enhancement.
- PDF export uses the browser print dialog; TXT export is direct.
- The source was checked for backend JavaScript syntax. Dependency installation/build verification could not complete in the authoring environment, so run the setup/build commands above in your deployment environment before production release.
